<?php

$nome = "$_POST[nome]";
$cor = "$_POST[cor]";
$valor = "$_POST[valor]";
$quantidade = "$_POST[quantidade]";
$cnpj = "$_POST[cnpj]";
$data_compra = "$_POST[data_compra]";
$codigo_fiscal = "$_POST[codigo_fiscal]"

try{
    $con = new PDO("mysql:host=localhost;dbname=tcc", "root", "");
} catch (PDOException $e) {
    print "Erro: {$e->getMessage()}<br>";
    exit;
}
try{

    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $cadastro=$con->exec ("INSERT INTO produto(codigo_fiscal, nome, cor, valor, quantidade, cnpj, data_compra) 
    VALUES ('$codigo_fiscal','$nome','$cor','$valor','$quantidade', '$cnpj' , '$data_compra')");

} catch (PDOException $e){
   
    $con->rollBack();

    print "Erro:{$e->getMessage()}<br>";
}
?>