<?php

$sql = new mysqli('localhost', 'root', '', 'tcc');

$sql->set_charset("utf8");
?>